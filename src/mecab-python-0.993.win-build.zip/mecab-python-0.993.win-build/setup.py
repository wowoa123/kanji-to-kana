#!/usr/bin/env python
from distutils.core import setup,Extension
import platform
if platform.machine() == 'AMD64':
    dir = 'C:/Program Files (x86)/MeCab/sdk'
else:
    dir = 'C:/Program Files/MeCab/sdk'
setup(name = 'mecab-python',
    version = '0.993',
    py_modules=['MeCab'],
    ext_modules = [
        Extension('_MeCab',
            ['MeCab_wrap.cxx',],
            include_dirs=[dir],
            library_dirs=[dir],
#            library_dirs=['.'],
            libraries=['libmecab'])])
